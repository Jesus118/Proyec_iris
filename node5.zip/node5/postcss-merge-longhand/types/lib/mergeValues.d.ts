declare const _exports: (...rules: import('postcss').Declaration[]) => string;
export = _exports;
