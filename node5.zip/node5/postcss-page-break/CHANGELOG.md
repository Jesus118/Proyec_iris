# Change Log
This project adheres to [Semantic Versioning](http://semver.org/).

## 3.0.3 - 2020-09-27
- Use `Declaration` event to work faster
- Fast check with `startsWith` before running slow regexp
- Avoid adding duplicate
Thanks to @ai

## 3.0.0  - 2020-09-20
* Updated: Support for PostCSS v8

## 2.0 - 2018-09-18
* Updated: Support for PostCSS v7

## 1.0
* Initial release
