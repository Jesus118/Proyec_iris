declare function _exports(columns: import('postcss-value-parser').ParsedValue): import('postcss-value-parser').ParsedValue | string;
export = _exports;
