# @mui/core-downloads-tracker

This package does not contain any code.
It is used solely to track number of downloads of @mui/material and @mui/joy (the only packages that depend on it) and help us determine the number of users of @mui/base.
Counting downloads is done by npm (as for every other package).
