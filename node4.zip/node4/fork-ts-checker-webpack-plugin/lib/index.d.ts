import { ForkTsCheckerWebpackPlugin } from './ForkTsCheckerWebpackPlugin';
export = ForkTsCheckerWebpackPlugin;
