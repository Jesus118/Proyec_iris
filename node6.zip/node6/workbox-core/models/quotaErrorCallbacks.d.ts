import '../_version.js';
declare const quotaErrorCallbacks: Set<Function>;
export { quotaErrorCallbacks };
