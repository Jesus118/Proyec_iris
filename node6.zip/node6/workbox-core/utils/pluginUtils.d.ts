import { WorkboxPlugin } from '../types.js';
import '../_version.js';
export declare const pluginUtils: {
    filter: (plugins: WorkboxPlugin[], callbackName: string) => WorkboxPlugin[];
};
