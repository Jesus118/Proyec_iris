import './_version.js';
/**
 * This method is deprecated, and will be removed in Workbox v7.
 *
 * Calling self.skipWaiting() is equivalent, and should be used instead.
 *
 * @memberof workbox-core
 */
declare function skipWaiting(): void;
export { skipWaiting };
