import '../_version.js';
export declare const CACHE_UPDATED_MESSAGE_TYPE = "CACHE_UPDATED";
export declare const CACHE_UPDATED_MESSAGE_META = "workbox-broadcast-update";
export declare const NOTIFY_ALL_CLIENTS = true;
export declare const DEFAULT_HEADERS_TO_CHECK: string[];
