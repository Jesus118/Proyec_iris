function _newArrowCheck(n, r) {
  if (n !== r) throw new TypeError("Cannot instantiate an arrow function");
}
module.exports = _newArrowCheck, module.exports.__esModule = true, module.exports["default"] = module.exports;